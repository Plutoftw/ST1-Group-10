from tkinter import Tk, Label, Entry, Button
import pandas as pd
import joblib
from sklearn.preprocessing import StandardScaler

# Load the model and the saved scaler
best_model_instance = joblib.load('firstrun.pkl')
scaler = joblib.load('scaler.pkl')  # Load the scaler

# Function to convert user input to a dictionary, scale it, and make a prediction
def convert_to_dict(values, results_text):
    try:
        # Convert user input to numerical values
        user_input = [float(value) if value else 0 for value in values]

        # Create a DataFrame from user input
        user_input_frame = pd.DataFrame([user_input], columns=["Year", "Kilometers_Driven", "Mileage", "Engine", "Power", "Seats"])

        # Convert the DataFrame to a NumPy array before scaling (to avoid feature names)
        user_input_array = user_input_frame.values

        # Scale the user input using StandardScaler (pre-fitted during training)
        scaled_input = scaler.transform(user_input_array)

        # Make a prediction using the scaled input
        user_prediction = best_model_instance.predict(scaled_input)


        # Display the prediction result
        results_text.config(text=f"${user_prediction[0]:.2f}", font="16")
    
    except ValueError as e:
        results_text.config(text="Please enter valid numbers for all fields.", font="16")
        print(f"ValueError: {e}")

# Class for the GUI
class EstimatorGUI:
    def __init__(self):
        window = Tk()
        window.title("Price Prediction Model")

        # Title text
        self.main_text = Label(window, text="Used Car Price Prediction Model", font=("Arial", 24, "bold"))
        self.main_text.grid(column=0, row=0, columnspan=2, pady=(0, 10), sticky="n")

        # Input fields and labels
        self.year_input = Entry(window)
        self.year_input.grid(column=1, row=1, sticky="e")
        self.year_text = Label(window, text="Enter value for Year: ", font=("Arial", 12))
        self.year_text.grid(column=0, row=1, sticky="w")

        self.kilometres_input = Entry(window)
        self.kilometres_input.grid(column=1, row=2, sticky="e")
        self.kilometres_text = Label(window, text="Enter value for Kilometres Driven: ", font=("Arial", 12))
        self.kilometres_text.grid(column=0, row=2, sticky="w")

        self.mileage_input = Entry(window)
        self.mileage_input.grid(column=1, row=3, sticky="e")
        self.mileage_text = Label(window, text="Enter value for Mileage: ", font=("Arial", 12))
        self.mileage_text.grid(column=0, row=3, sticky="w")

        self.engine_input = Entry(window)
        self.engine_input.grid(column=1, row=4, sticky="e")
        self.engine_text = Label(window, text="Enter value for Engine: ", font=("Arial", 12))
        self.engine_text.grid(column=0, row=4, sticky="w")

        self.power_input = Entry(window)
        self.power_input.grid(column=1, row=5, sticky="e")
        self.power_text = Label(window, text="Enter value for Power: ", font=("Arial", 12))
        self.power_text.grid(column=0, row=5, sticky="w")

        self.seats_input = Entry(window)
        self.seats_input.grid(column=1, row=6, sticky="e")
        self.seats_text = Label(window, text="Enter value for Seats: ", font=("Arial", 12))
        self.seats_text.grid(column=0, row=6, sticky="w")

        # Button to estimate the price
        self.estimate_button = Button(window, text="Estimate", command=self.calculate)
        self.estimate_button.grid(row=7, column=0, sticky="nsew", columnspan=2, padx=0, pady=(10, 0))

        # Labels to display results
        self.results_text = Label(window, text="Predicted Price based on your input: ", font=("Arial", 14))
        self.results_text.grid(column=0, row=8, sticky="n", pady=30, columnspan=2)

        self.results = Label(window, text="", font=("Arial", 16))
        self.results.grid(column=0, row=9, sticky="n", pady=(0, 30), columnspan=2)

        window.mainloop()

    # Function to capture user input and make a prediction
    def calculate(self):
        # Get values from the input fields
        year = self.year_input.get()
        kilometres_driven = self.kilometres_input.get()
        mileage = self.mileage_input.get()
        engine = self.engine_input.get()
        power = self.power_input.get()
        seats = self.seats_input.get()

        try:
            print("Calculate is called.")
            new_values = [
                year,
                kilometres_driven,
                mileage,
                engine,
                power,
                seats,
            ]
            print(f"Year: '{year}', Kilometres Driven: '{kilometres_driven}', "
                  f"Mileage: '{mileage}', Engine: '{engine}', "
                  f"Power: '{power}', Seats: '{seats}'")
            
            # Check for missing input
            if any(not value for value in new_values):
                self.results.config(text="Please fill in all fields.", font="12")
                return

            # Convert the input and calculate the price prediction
            convert_to_dict(new_values, self.results)

        # Handle any exceptions that occur during the calculation
        except Exception as e:
            print(f"An error occurred: {e}")

# Run the GUI
EstimatorGUI()
